'use strict';
// Shared checklist app for the hub's checklist pages (post-trip,
// departure, fuelling). Each page sets window.CK with its own run
// wording before this script loads; the defaults are the post-trip
// closeout words.
const $ = id => document.getElementById(id);
const BASE = location.pathname.replace(/\/+$/, '');
const L = Object.assign({
  emptyRun: 'No closeout is open right now. When the boat comes back in, start one and work down the list.',
  startBtn: 'Start closeout',
  inProgress: 'Closeout in progress',
  byLabel: 'Closed out by',
  noteLabel: 'Close-out note (optional)',
  notePlaceholder: 'Anything used up, running low, or worth flagging',
  finishBtn: 'Finish closeout',
  discardConfirm: 'Discard this closeout without saving it?',
  historyEmpty: 'No finished closeouts yet.',
}, window.CK || {});
let state = null;
let editing = false;

async function api(path, body) {
  const opts = { headers: { 'Content-Type': 'application/json' } };
  if (body !== undefined) { opts.method = 'POST'; opts.body = JSON.stringify(body); }
  const r = await fetch(BASE + path, opts);
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || ('HTTP ' + r.status));
  return data;
}
function escapeHtml(s) {
  return String(s === null || s === undefined ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
function fmtDateTime(iso) {
  if (!iso) return '';
  return new Intl.DateTimeFormat('en-US', {
    timeZone: 'America/New_York', weekday: 'short', month: 'short', day: 'numeric',
    hour: 'numeric', minute: '2-digit',
  }).format(new Date(iso));
}
function fmtTime(iso) {
  if (!iso) return '';
  return new Intl.DateTimeFormat('en-US', {
    timeZone: 'America/New_York', hour: 'numeric', minute: '2-digit',
  }).format(new Date(iso));
}
function personName() {
  const el = $('personName');
  const v = el ? el.value.trim() : '';
  return v || (localStorage.getItem('ckPerson') || '');
}

async function load() {
  state = await api('/api/state');
  render();
}

function groupedTasks() {
  const groups = [];
  const bySection = new Map();
  for (const t of state.tasks) {
    if (!bySection.has(t.section)) { bySection.set(t.section, []); groups.push(t.section); }
    bySection.get(t.section).push(t);
  }
  return groups.map(name => ({ name, tasks: bySection.get(name) }));
}

function renderRunPanel() {
  const panel = $('runPanel');
  const total = state.tasks.length;
  if (!state.openRun) {
    panel.innerHTML = `
      <div style="font-size:15px;margin-bottom:10px">${escapeHtml(L.emptyRun)}</div>
      <button class="btn gold big" id="startBtn" type="button">${escapeHtml(L.startBtn)}</button>`;
    $('startBtn').onclick = async () => { await api('/api/run/start', {}); await load(); };
    return;
  }
  const checked = new Set(state.openRun.checkedTaskIds);
  const pct = total ? Math.round(checked.size * 100 / total) : 0;
  panel.innerHTML = `
    <div style="font-weight:700;font-size:16px">${escapeHtml(L.inProgress)}</div>
    <div class="progress"><div class="fill" style="width:${pct}%"></div></div>
    <div class="progress-label">${checked.size} of ${total} tasks checked · started ${escapeHtml(fmtDateTime(state.openRun.startedAt))}</div>
    <label class="flabel">Who is working<input class="finput" id="personName" placeholder="Your name, for example Kori"></label>
    <div class="progress-label">Every task you check is stamped with this name and the time, so we know who did what. Change the name when a different person takes over.</div>
    <label class="flabel">${escapeHtml(L.byLabel)}<input class="finput" id="finishBy" placeholder="Your name"></label>
    <label class="flabel">${escapeHtml(L.noteLabel)}<input class="finput" id="finishNote" placeholder="${escapeHtml(L.notePlaceholder)}"></label>
    <div class="btnrow">
      <button class="btn green" id="finishBtn" type="button">${escapeHtml(L.finishBtn)}</button>
      <button class="btn alt" id="cancelRunBtn" type="button">Discard</button>
    </div>`;
  const savedPerson = localStorage.getItem('ckPerson') || '';
  if (savedPerson) { $('personName').value = savedPerson; $('finishBy').value = savedPerson; }
  $('personName').addEventListener('input', () => {
    localStorage.setItem('ckPerson', $('personName').value.trim());
    $('finishBy').value = $('personName').value;
  });
  $('finishBtn').onclick = async () => {
    await api('/api/run/finish', { closedBy: $('finishBy').value, note: $('finishNote').value });
    await load();
  };
  $('cancelRunBtn').onclick = async () => {
    if (!confirm(L.discardConfirm)) return;
    await api('/api/run/cancel', {});
    await load();
  };
}

function renderTasks() {
  const list = $('taskList');
  const checked = state.openRun ? new Set(state.openRun.checkedTaskIds) : new Set();
  const inRun = !!state.openRun;
  let html = '';
  for (const g of groupedTasks()) {
    html += `<h2 class="section">${escapeHtml(g.name)}</h2>`;
    for (const t of g.tasks) {
      const done = checked.has(t.id);
      const byInfo = done && state.openRun && state.openRun.checkedBy ? state.openRun.checkedBy[String(t.id)] : null;
      html += `<div class="task ${inRun ? 'tappable' : ''} ${done ? 'done' : ''}" data-id="${t.id}">
        ${inRun ? `<div class="box">${done ? '&#10003;' : ''}</div>` : ''}
        <div>
          <div class="title">${escapeHtml(t.title)}</div>
          ${t.note ? `<div class="note">${escapeHtml(t.note)}</div>` : ''}
          ${byInfo && byInfo.by ? `<div class="by">Done by ${escapeHtml(byInfo.by)}${byInfo.at ? ' · ' + escapeHtml(fmtTime(byInfo.at)) : ''}</div>` : ''}
        </div>
        ${editing ? `<div class="tools">
          <button class="toolbtn" data-act="up" data-id="${t.id}" type="button">Up</button>
          <button class="toolbtn" data-act="down" data-id="${t.id}" type="button">Down</button>
          <button class="toolbtn" data-act="edit" data-id="${t.id}" type="button">Edit</button>
        </div>` : ''}
      </div>`;
    }
  }
  if (!state.tasks.length) html = '<div class="empty">The list is empty. Use Edit list, then Add task, to build it.</div>';
  list.innerHTML = html;
  list.querySelectorAll('.task.tappable').forEach(el => {
    el.addEventListener('click', async e => {
      if (e.target.closest('.tools')) return;
      const taskId = Number(el.dataset.id);
      const isDone = state.openRun && state.openRun.checkedTaskIds.includes(taskId);
      const by = personName();
      if (!isDone && !by) {
        alert('Put your name in "Who is working" at the top first, so we know who did this task.');
        $('runPanel').scrollIntoView({ behavior: 'smooth', block: 'start' });
        const pn = $('personName');
        if (pn) pn.focus();
        return;
      }
      await api('/api/run/toggle', { taskId, by });
      await load();
    });
  });
  list.querySelectorAll('.toolbtn').forEach(btn => {
    btn.addEventListener('click', async e => {
      e.stopPropagation();
      const id = Number(btn.dataset.id);
      if (btn.dataset.act === 'edit') return openTaskDialog(id);
      await api('/api/task/move', { id, dir: btn.dataset.act });
      await load();
    });
  });
}

function renderHistory() {
  const el = $('historyList');
  if (!state.history.length) {
    el.innerHTML = '<div class="empty">' + escapeHtml(L.historyEmpty) + '</div>';
    return;
  }
  el.innerHTML = state.history.map(h => {
    const pct = h.totalCount ? Math.round(h.checkedCount * 100 / h.totalCount) : 0;
    const groups = new Map();
    for (const id of (h.checkedTaskIds || [])) {
      const t = state.tasks.find(x => x.id === id);
      const info = h.checkedBy ? h.checkedBy[String(id)] : null;
      const who = (info && info.by) ? info.by : 'No name recorded';
      if (!groups.has(who)) groups.set(who, []);
      groups.get(who).push(t ? t.title : ('Task ' + id));
    }
    const whoHtml = [...groups.entries()].map(([who, titles]) =>
      `<br><strong>${escapeHtml(who)}:</strong> ${titles.map(escapeHtml).join(', ')}`).join('');
    return `<div class="card">
      <div class="desc">${escapeHtml(fmtDateTime(h.finishedAt))}</div>
      <div class="meta">${h.checkedCount} of ${h.totalCount} tasks (${pct}%)${h.closedBy ? ' · ' + escapeHtml(L.byLabel) + ' ' + escapeHtml(h.closedBy) : ''}${h.note ? '<br>' + escapeHtml(h.note) : ''}${whoHtml}</div>
    </div>`;
  }).join('');
}

function render() {
  renderRunPanel();
  renderTasks();
  renderHistory();
  $('sectionNames').innerHTML = state.sections.map(s => `<option value="${escapeHtml(s)}">`).join('');
}

// ---- task editing ----
function openTaskDialog(id) {
  const t = id ? state.tasks.find(x => x.id === id) : null;
  $('taskDlgTitle').textContent = t ? 'Edit task' : 'Add task';
  $('t_id').value = t ? t.id : '';
  $('t_section').value = t ? t.section : '';
  $('t_title').value = t ? t.title : '';
  $('t_note').value = t ? (t.note || '') : '';
  $('taskDeleteBtn').style.display = t ? '' : 'none';
  $('taskDlg').showModal();
}
$('addTaskBtn').onclick = () => openTaskDialog(null);
$('taskCancelBtn').onclick = () => $('taskDlg').close();
$('taskDeleteBtn').onclick = async () => {
  const id = Number($('t_id').value);
  if (!id || !confirm('Delete this task from the list? Past runs keep their record.')) return;
  await api('/api/task/delete', { id });
  $('taskDlg').close();
  await load();
};
$('taskForm').addEventListener('submit', async e => {
  e.preventDefault();
  const body = {
    section: $('t_section').value,
    title: $('t_title').value,
    note: $('t_note').value,
  };
  if ($('t_id').value) body.id = Number($('t_id').value);
  await api('/api/task', body);
  $('taskDlg').close();
  await load();
});
$('editToggleBtn').onclick = () => {
  editing = !editing;
  $('editToggleBtn').textContent = editing ? 'Done editing' : 'Edit list';
  $('addTaskBtn').style.display = editing ? '' : 'none';
  renderTasks();
};

load().catch(e => {
  $('runPanel').innerHTML = '<div class="empty">Could not load. ' + escapeHtml(e.message) + '</div>';
});
