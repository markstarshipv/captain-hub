// Par Inventory module for the Captain Spurling hub.
// Adapted from the standalone starship-v-par-inventory app with no behavior
// changes, except: auth is the hub's (the router is mounted behind the hub
// sign-in), and in Postgres mode it uses the hub's shared pool.
// CRITICAL: the Postgres table name and schema (table "items") and the
// seed-only-when-empty behavior are exactly those of the live standalone
// app, because this module reads the same live database.
'use strict';
const express = require('express');
const fs = require('fs');
const path = require('path');

const seed = require('../seeds/inventory.json');

function rawOrderQty(it) {
  return (it.currentCount === null || it.currentCount === undefined)
    ? 0 : Math.max(0, Math.round((Number(it.parQty) - Number(it.currentCount)) * 100) / 100);
}
function minOrderOf(it) {
  return (it.minOrderQty === null || it.minOrderQty === undefined) ? null : Number(it.minOrderQty);
}
function itemStatus(it) {
  if (it.currentCount === null || it.currentCount === undefined) return 'not_counted';
  const c = Number(it.currentCount);
  // Held by the per-item minimum: below par, but the need (par minus count)
  // has not reached the item's minimum order quantity, so it does not order
  // yet. While held it shows under_min instead of reorder or top_up.
  const min = minOrderOf(it);
  const need = rawOrderQty(it);
  if (min && need > 0 && need < min) return 'under_min';
  if (it.reorderQty !== null && it.reorderQty !== undefined && c <= Number(it.reorderQty)) return 'reorder';
  if (c < Number(it.parQty)) return 'top_up';
  return 'stocked';
}
function decorate(it) {
  const status = itemStatus(it);
  const orderQty = rawOrderQty(it);
  const min = minOrderOf(it);
  return { ...it, status, orderQty, needsOrder: orderQty > 0 && (!min || orderQty >= min) };
}
function fmtQty(n) {
  if (n === null || n === undefined) return '';
  return Number.isInteger(Number(n)) ? String(Number(n)) : String(Number(n));
}

function createInventory({ pool, dataFile, requireAuth, reportToken }) {
  const router = express.Router();
  let store;

  async function init() {
    if (pool) {
      await pool.query(`CREATE TABLE IF NOT EXISTS items (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        category TEXT NOT NULL,
        par_qty NUMERIC NOT NULL,
        reorder_qty NUMERIC,
        unit TEXT NOT NULL,
        vendor TEXT NOT NULL,
        notes TEXT DEFAULT '',
        reorder_text TEXT DEFAULT '',
        cadence TEXT DEFAULT 'monitor',
        sort_order INTEGER DEFAULT 0,
        current_count NUMERIC,
        last_counted_at TIMESTAMPTZ
      )`);
      await pool.query(`ALTER TABLE items ADD COLUMN IF NOT EXISTS carried BOOLEAN DEFAULT FALSE`);
      await pool.query(`ALTER TABLE items ADD COLUMN IF NOT EXISTS min_order_qty NUMERIC`);
      const { rows } = await pool.query('SELECT COUNT(*)::int AS n FROM items');
      if (rows[0].n === 0) {
        for (const s of seed) {
          await pool.query(
            `INSERT INTO items (name, category, par_qty, reorder_qty, unit, vendor, notes, reorder_text, cadence, sort_order)
             VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
            [s.name, s.category, s.parQty, s.reorderQty, s.unit, s.vendor, s.notes || '', s.reorderText || '', s.cadence || 'monitor', s.sortOrder || 0]
          );
        }
      }
      await pool.query(`CREATE TABLE IF NOT EXISTS cart_requests (
        id SERIAL PRIMARY KEY,
        created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
        status TEXT NOT NULL DEFAULT 'pending',
        payload JSONB NOT NULL,
        result JSONB,
        updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
      )`);
      store = { mode: 'pg', pool };
    } else {
      let data;
      if (fs.existsSync(dataFile)) {
        data = JSON.parse(fs.readFileSync(dataFile, 'utf8'));
      } else {
        data = { nextId: seed.length + 1, items: seed.map((s, i) => ({ id: i + 1, ...s, currentCount: null, lastCountedAt: null, carried: false })) };
        fs.writeFileSync(dataFile, JSON.stringify(data, null, 1));
      }
      if (!Array.isArray(data.cartRequests)) data.cartRequests = [];
      if (!data.nextCartId) data.nextCartId = 1;
      store = { mode: 'file', file: dataFile, data };
    }
  }

  function rowToItem(r) {
    return {
      id: r.id, name: r.name, category: r.category,
      parQty: r.par_qty !== undefined ? Number(r.par_qty) : r.parQty,
      reorderQty: (r.reorder_qty !== undefined ? r.reorder_qty : r.reorderQty) === null ? null : Number(r.reorder_qty !== undefined ? r.reorder_qty : r.reorderQty),
      minOrderQty: (r.min_order_qty !== undefined ? r.min_order_qty : r.minOrderQty) == null ? null : Number(r.min_order_qty !== undefined ? r.min_order_qty : r.minOrderQty),
      unit: r.unit, vendor: r.vendor, notes: r.notes || '',
      reorderText: r.reorder_text !== undefined ? r.reorder_text : (r.reorderText || ''),
      cadence: r.cadence, sortOrder: r.sort_order !== undefined ? r.sort_order : r.sortOrder,
      currentCount: (r.current_count !== undefined ? r.current_count : r.currentCount) === null ? null : Number(r.current_count !== undefined ? r.current_count : r.currentCount),
      lastCountedAt: (r.last_counted_at !== undefined ? r.last_counted_at : r.lastCountedAt) || null,
      carried: !!r.carried,
    };
  }

  async function listItems() {
    if (store.mode === 'pg') {
      const { rows } = await store.pool.query('SELECT * FROM items ORDER BY sort_order, id');
      return rows.map(rowToItem);
    }
    return [...store.data.items].sort((a, b) => (a.sortOrder - b.sortOrder) || (a.id - b.id)).map(it => ({
      ...it, carried: !!it.carried,
      minOrderQty: it.minOrderQty === null || it.minOrderQty === undefined ? null : Number(it.minOrderQty),
    }));
  }
  function saveFile() {
    if (store.mode === 'file') fs.writeFileSync(store.file, JSON.stringify(store.data, null, 1));
  }
  async function updateCount(id, count) {
    const now = new Date().toISOString();
    if (store.mode === 'pg') {
      await store.pool.query('UPDATE items SET current_count=$1, last_counted_at=$2, carried=FALSE WHERE id=$3', [count, now, id]);
    } else {
      const it = store.data.items.find(i => i.id === id);
      if (it) { it.currentCount = count; it.lastCountedAt = now; it.carried = false; }
      saveFile();
    }
  }
  async function restockVendor(vendor) {
    const items = await listItems();
    const now = new Date().toISOString();
    for (const it of items) {
      if (it.vendor === vendor && it.currentCount !== null && Number(it.currentCount) < Number(it.parQty)) {
        if (store.mode === 'pg') {
          await store.pool.query('UPDATE items SET current_count=$1, last_counted_at=$2, carried=FALSE WHERE id=$3', [it.parQty, now, it.id]);
        } else {
          const f = store.data.items.find(i => i.id === it.id);
          if (f) { f.currentCount = Number(it.parQty); f.lastCountedAt = now; f.carried = false; }
        }
      }
    }
    saveFile();
  }
  async function startNewCount() {
    // Counts carry forward: nothing is cleared. Every item that has a count
    // is flagged carried (last round's value, not yet confirmed this round)
    // until its count is saved again. Timestamps stay as they are: they show
    // when the standing value was actually entered.
    if (store.mode === 'pg') {
      await store.pool.query('UPDATE items SET carried=TRUE WHERE current_count IS NOT NULL');
    } else {
      store.data.items.forEach(i => { if (i.currentCount !== null && i.currentCount !== undefined) i.carried = true; });
      saveFile();
    }
  }
  async function upsertItem(body, id) {
    const vals = {
      name: String(body.name || '').trim(), category: String(body.category || '').trim(),
      parQty: Number(body.parQty), reorderQty: body.reorderQty === '' || body.reorderQty === null || body.reorderQty === undefined ? null : Number(body.reorderQty),
      minOrderQty: body.minOrderQty === '' || body.minOrderQty === null || body.minOrderQty === undefined ? null : Number(body.minOrderQty),
      unit: String(body.unit || '').trim(), vendor: String(body.vendor || '').trim(),
      notes: String(body.notes || ''), reorderText: String(body.reorderText || ''),
      cadence: String(body.cadence || 'monitor'), sortOrder: Number(body.sortOrder || 0),
    };
    if (!vals.name || !vals.category || !vals.unit || !vals.vendor || isNaN(vals.parQty)) throw new Error('Missing required item fields');
    if (vals.minOrderQty !== null && (isNaN(vals.minOrderQty) || vals.minOrderQty < 0)) throw new Error('Minimum order quantity must be a number 0 or more');
    if (store.mode === 'pg') {
      if (id) {
        await store.pool.query(`UPDATE items SET name=$1, category=$2, par_qty=$3, reorder_qty=$4, unit=$5, vendor=$6, notes=$7, reorder_text=$8, cadence=$9, sort_order=$10, min_order_qty=$11 WHERE id=$12`,
          [vals.name, vals.category, vals.parQty, vals.reorderQty, vals.unit, vals.vendor, vals.notes, vals.reorderText, vals.cadence, vals.sortOrder, vals.minOrderQty, id]);
        return id;
      }
      const { rows } = await store.pool.query(`INSERT INTO items (name, category, par_qty, reorder_qty, unit, vendor, notes, reorder_text, cadence, sort_order, min_order_qty) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING id`,
        [vals.name, vals.category, vals.parQty, vals.reorderQty, vals.unit, vals.vendor, vals.notes, vals.reorderText, vals.cadence, vals.sortOrder, vals.minOrderQty]);
      return rows[0].id;
    }
    if (id) {
      const it = store.data.items.find(i => i.id === id);
      if (it) Object.assign(it, vals);
      saveFile();
      return id;
    }
    const nid = store.data.nextId++;
    store.data.items.push({ id: nid, ...vals, currentCount: null, lastCountedAt: null, carried: false });
    saveFile();
    return nid;
  }
  async function deleteItem(id) {
    if (store.mode === 'pg') {
      await store.pool.query('DELETE FROM items WHERE id=$1', [id]);
    } else {
      store.data.items = store.data.items.filter(i => i.id !== id);
      saveFile();
    }
  }

  // ---------------- report builder ----------------
  async function buildReport() {
    const items = (await listItems()).map(decorate);
    const byVendor = {};
    let toOrder = 0, reorderCount = 0, counted = 0;
    for (const it of items) {
      if (it.currentCount !== null) counted++;
      if (it.needsOrder) {
        toOrder++;
        if (it.status === 'reorder') reorderCount++;
        (byVendor[it.vendor] = byVendor[it.vendor] || []).push({
          name: it.name, have: it.currentCount, par: it.parQty, order: it.orderQty,
          unit: it.unit, flag: it.status === 'reorder' ? 'REORDER' : 'Below par', notes: it.notes,
        });
      }
    }
    return { generatedAt: new Date().toISOString(), total: items.length, counted, toOrder, reorderCount, byVendor };
  }

  // ---------------- shopping cart requests ----------------
  // The "Build shopping carts" button stores a request here; Marley's
  // watcher picks it up from the token feed and builds the carts at
  // Sam's Club, Walmart, and Amazon. Statuses: pending -> claimed -> built.
  function vendorCounts(report) {
    const counts = {};
    for (const v of Object.keys(report.byVendor)) counts[v] = report.byVendor[v].length;
    return counts;
  }
  function rowToCartRequest(r) {
    return {
      id: r.id,
      createdAt: r.created_at !== undefined ? new Date(r.created_at).toISOString() : r.createdAt,
      status: r.status,
      payload: typeof r.payload === 'string' ? JSON.parse(r.payload) : r.payload,
      result: r.result == null ? null : (typeof r.result === 'string' ? JSON.parse(r.result) : r.result),
      updatedAt: r.updated_at !== undefined ? new Date(r.updated_at).toISOString() : r.updatedAt,
    };
  }
  async function listCartRequests() {
    if (store.mode === 'pg') {
      const { rows } = await store.pool.query('SELECT * FROM cart_requests ORDER BY id');
      return rows.map(rowToCartRequest);
    }
    return [...store.data.cartRequests].sort((a, b) => a.id - b.id);
  }
  async function createCartRequest() {
    const report = await buildReport();
    if (!report.toOrder) return { empty: true };
    const existing = (await listCartRequests()).find(r => r.status === 'pending' || r.status === 'claimed');
    if (existing) return { alreadyQueued: true, request: existing };
    const now = new Date().toISOString();
    if (store.mode === 'pg') {
      const { rows } = await store.pool.query(
        `INSERT INTO cart_requests (payload) VALUES ($1) RETURNING *`, [JSON.stringify(report)]);
      return { request: rowToCartRequest(rows[0]) };
    }
    const req = { id: store.data.nextCartId++, createdAt: now, status: 'pending', payload: report, result: null, updatedAt: now };
    store.data.cartRequests.push(req);
    saveFile();
    return { request: req };
  }
  async function pendingCartRequests() {
    const staleBefore = Date.now() - 2 * 60 * 60 * 1000;
    return (await listCartRequests()).filter(r =>
      r.status === 'pending' || (r.status === 'claimed' && new Date(r.updatedAt).getTime() < staleBefore));
  }
  async function latestCartRequest() {
    const all = await listCartRequests();
    return all.length ? all[all.length - 1] : null;
  }
  async function setCartRequestStatus(id, status, result) {
    const now = new Date().toISOString();
    if (store.mode === 'pg') {
      const { rows } = await store.pool.query(
        `UPDATE cart_requests SET status=$1, result=$2, updated_at=$3 WHERE id=$4 RETURNING *`,
        [status, result ? JSON.stringify(result) : null, now, id]);
      return rows.length ? rowToCartRequest(rows[0]) : null;
    }
    const req = store.data.cartRequests.find(r => r.id === id);
    if (!req) return null;
    req.status = status;
    if (result !== undefined) req.result = result;
    req.updatedAt = now;
    saveFile();
    return req;
  }

  // Token-protected report feed for the Monday email job. Registered before
  // the hub auth middleware: it answers to the token, not the sign-in cookie.
  router.get('/api/report.json', async (req, res) => {
    if (!reportToken || req.query.token !== reportToken) return res.status(403).json({ error: 'Forbidden' });
    res.json(await buildReport());
  });

  // Token-protected cart-request feed for the cart-builder watcher: list
  // pending requests, and let the watcher claim / complete them.
  router.get('/api/cart-requests.json', async (req, res) => {
    if (!reportToken || req.query.token !== reportToken) return res.status(403).json({ error: 'Forbidden' });
    res.json({ requests: await pendingCartRequests() });
  });
  router.post('/api/cart-requests/status', async (req, res) => {
    if (!reportToken || !req.body || req.body.token !== reportToken) return res.status(403).json({ error: 'Forbidden' });
    const id = Number(req.body.id);
    const status = String(req.body.status || '');
    if (!id || !['claimed', 'built', 'failed', 'pending'].includes(status)) return res.status(400).json({ error: 'Bad status update' });
    const updated = await setCartRequestStatus(id, status, req.body.result);
    if (!updated) return res.status(404).json({ error: 'No such request' });
    res.json({ ok: true, request: updated });
  });

  router.use(requireAuth);

  // ---------------- api ----------------
  router.get('/api/items', async (req, res) => {
    const items = (await listItems()).map(decorate);
    const counted = items.filter(i => i.currentCount !== null).length;
    res.json({ total: items.length, counted, toOrder: items.filter(i => i.needsOrder).length, reorderCount: items.filter(i => i.status === 'reorder').length, items });
  });
  router.post('/api/count', async (req, res) => {
    const id = Number(req.body.id);
    const count = req.body.count === null || req.body.count === '' ? null : Number(req.body.count);
    if (!id || (count !== null && (isNaN(count) || count < 0))) return res.status(400).json({ error: 'Bad count' });
    await updateCount(id, count);
    res.json({ ok: true });
  });
  router.get('/api/report', async (req, res) => res.json(await buildReport()));
  router.post('/api/cart-request', async (req, res) => {
    const out = await createCartRequest();
    if (out.empty) return res.status(400).json({ error: 'Nothing to order. Count items first, and only items below par go in the carts.' });
    res.json({
      ok: true, alreadyQueued: !!out.alreadyQueued,
      request: { id: out.request.id, createdAt: out.request.createdAt, status: out.request.status, counts: vendorCounts(out.request.payload) },
    });
  });
  router.get('/api/cart-request/latest', async (req, res) => {
    const latest = await latestCartRequest();
    res.json({
      request: latest ? { id: latest.id, createdAt: latest.createdAt, status: latest.status, counts: vendorCounts(latest.payload), result: latest.result, updatedAt: latest.updatedAt } : null,
    });
  });
  router.post('/api/restock', async (req, res) => { await restockVendor(String(req.body.vendor || '')); res.json({ ok: true }); });
  router.post('/api/newcount', async (req, res) => { await startNewCount(); res.json({ ok: true }); });
  router.post('/api/item', async (req, res) => {
    try { const id = await upsertItem(req.body, req.body.id ? Number(req.body.id) : null); res.json({ ok: true, id }); }
    catch (e) { res.status(400).json({ error: e.message }); }
  });
  router.post('/api/item/delete', async (req, res) => { await deleteItem(Number(req.body.id)); res.json({ ok: true }); });

  // ---------------- exports ----------------
  router.get('/export/order.pdf', async (req, res) => {
    const PDFDocument = require('pdfkit');
    const report = await buildReport();
    const dateStr = new Date().toLocaleDateString('en-US', { timeZone: 'America/New_York', year: 'numeric', month: 'long', day: 'numeric' });
    const doc = new PDFDocument({ margin: 48 });
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', 'attachment; filename="Starship-V-Order-Report.pdf"');
    doc.pipe(res);
    doc.fontSize(18).font('Helvetica-Bold').text('Starship V, Weekly Order Report');
    doc.fontSize(11).font('Helvetica').text(dateStr);
    doc.moveDown(0.5);
    doc.text(`Items to order: ${report.toOrder} (${report.reorderCount} at or below reorder point). Counted ${report.counted} of ${report.total} items.`);
    doc.moveDown(1);
    const vendors = Object.keys(report.byVendor);
    if (!vendors.length) doc.text('Nothing to order. All counted items are at or above par.');
    for (const v of vendors) {
      doc.fontSize(14).font('Helvetica-Bold').text(v);
      doc.moveDown(0.3);
      for (const line of report.byVendor[v]) {
        doc.fontSize(11).font('Helvetica-Bold').text(`${line.name}: order ${fmtQty(line.order)} ${line.unit}  [${line.flag}]`, { continued: false });
        doc.fontSize(10).font('Helvetica').text(`On hand ${fmtQty(line.have)} of par ${fmtQty(line.par)} ${line.unit}.`);
        if (line.notes) doc.fontSize(10).font('Helvetica-Oblique').text(`Note: ${line.notes}`);
        doc.moveDown(0.4);
      }
      doc.moveDown(0.6);
    }
    doc.end();
  });
  router.get('/export/order.xlsx', async (req, res) => {
    const ExcelJS = require('exceljs');
    const report = await buildReport();
    const wb = new ExcelJS.Workbook();
    const summary = wb.addWorksheet('Summary');
    summary.addRow(['Starship V, Weekly Order Report']);
    summary.addRow(['Generated', new Date().toLocaleString('en-US', { timeZone: 'America/New_York' })]);
    summary.addRow(['Items to order', report.toOrder]);
    summary.addRow(['At or below reorder point', report.reorderCount]);
    summary.addRow(['Counted', `${report.counted} of ${report.total}`]);
    for (const v of Object.keys(report.byVendor)) {
      const ws = wb.addWorksheet(v.replace(/[^\w ]/g, '').slice(0, 28) || 'Vendor');
      ws.addRow(['Item', 'On hand', 'Par', 'Order', 'Unit', 'Flag', 'Notes']);
      for (const line of report.byVendor[v]) ws.addRow([line.name, line.have, line.par, line.order, line.unit, line.flag, line.notes || '']);
    }
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename="Starship-V-Order-Report.xlsx"');
    await wb.xlsx.write(res);
    res.end();
  });
  router.get('/api/report.txt', async (req, res) => {
    const report = await buildReport();
    let out = '';
    for (const v of Object.keys(report.byVendor)) {
      out += `${v}\n`;
      for (const line of report.byVendor[v]) out += `- ${line.name}: order ${fmtQty(line.order)} ${line.unit} (have ${fmtQty(line.have)}, par ${fmtQty(line.par)}) [${line.flag}]${line.notes ? ' Note: ' + line.notes : ''}\n`;
      out += '\n';
    }
    res.type('text/plain').send(out || 'Nothing to order.');
  });

  // ---------------- app shell ----------------
  router.get('/', (req, res) => res.sendFile(path.join(__dirname, '..', 'public', 'inventory', 'index.html')));
  router.use(express.static(path.join(__dirname, '..', 'public', 'inventory')));

  return { router, ready: init() };
}

module.exports = { createInventory };
